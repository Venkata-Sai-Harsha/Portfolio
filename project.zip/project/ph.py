import streamlit as st
import pickle
import numpy as np
import pandas as pd

# Load the trained models
with open('random_forest_model.pkl', 'rb') as file:
    random_forest_model = pickle.load(file)

# Add other models similarly if needed
# with open('logistic_regression_model.pkl', 'rb') as file:
#     logistic_regression_model = pickle.load(file)

# Define a function to extract features from the URL
def extract_features_from_url(url):
    features = {}

    # Example feature extraction - you should modify this according to your exact feature set
    features['use_of_ip'] = int(any(char.isdigit() for char in url))  # Simple check for IP address in URL
    features['abnormal_url'] = 1 if '//' in url[7:] else 0
    features['url_length'] = len(url)
    features['hostname_length'] = len(url.split('/')[2])  # Extract hostname and get its length
    features['short_url'] = 1 if len(url) < 20 else 0

    # Convert the features into a DataFrame to match the model input format
    feature_df = pd.DataFrame([features])

    return feature_df

# Streamlit app UI
st.title('Phishing URL Detection App')
st.write('Enter a URL to check if it is a phishing website or not.')

# User input
url_input = st.text_input('Enter URL:', '')

# If user clicks the 'Predict' button
if st.button('Predict'):
    if url_input:
        # Extract features from the URL
        features = extract_features_from_url(url_input)
        
        # Make prediction using the best model (Random Forest in this case)
        prediction = random_forest_model.predict(features)

        # Display the prediction result
        if prediction == 1:
            st.error('Warning: The URL is likely a phishing website!')
        else:
            st.success('The URL appears to be safe.')

    else:
        st.warning('Please enter a valid URL.')

# Optionally, you can display the accuracies of the models used in the app
st.sidebar.title('Model Accuracies')
st.sidebar.write('Logistic Regression (without SMOTE): 93%')
st.sidebar.write('Logistic Regression (with SMOTE): 96%')
st.sidebar.write('Random Forest (without SMOTE): 96.1%')
st.sidebar.write('Random Forest (with SMOTE): 96.1%')
st.sidebar.write('Decision Tree (without SMOTE): 96.1%')
st.sidebar.write('Decision Tree (with SMOTE): 96%')
st.sidebar.write('Gradient Descent (without SMOTE): 95.6%')
st.sidebar.write('Gradient Descent (with SMOTE): 95.6%')
st.sidebar.write('AdaBoost (without SMOTE): 95.4%')
st.sidebar.write('AdaBoost (with SMOTE): 95.6%')
st.sidebar.write('CNN: 89.5%')
st.sidebar.write('BiLSTM: 93.3%')